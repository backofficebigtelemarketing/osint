def check_username(username):
    return [f"https://namechk.com/{username}"]
