def search_google(query):
    return [f"https://www.google.com/search?q={query}"]
